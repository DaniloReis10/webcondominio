package condominio.beans;

import java.util.Date;

public class Funcionario {
	private long cpf;
	private String nome;
	private String email;
	private String sexo;
	private Date dataNascimento;
	private int ddd;
	private int telefone;
	private long rg;
	private String orgaoEmissor;
	private int idade;
	private String endereco;
	private String bairro;
	private String cidade;
	private String pais;
	private String estado;
	private String cargo;
	private Date dataContratacao;
	private String estadoCivil;
	private String salario;
	private int qtdeFilhos;
	private long carteiraTrabalho;
	private String horasdetrabalho;

	public Funcionario(long cpf, String nome, String email, String cargo) {
		super();
		this.cpf = cpf;
		this.nome = nome;
		this.email = email;
		this.cargo = cargo;
	}
	
	

	public Funcionario(long cpf, String nome, String email, String sexo,
			Date dataNascimento, int ddd, int telefone, long rg,
			String orgaoEmissor, int idade, String endereco, String bairro,
			String cidade, String pais, String estado, String cargo,
			Date dataContratacao, String estadoCivil, String salario,
			int qtdeFilhos, long carteiraTrabalho, String horadetrabalho) {
		super();
		this.cpf = cpf;
		this.nome = nome;
		this.email = email;
		this.sexo = sexo;
		this.dataNascimento = dataNascimento;
		this.ddd = ddd;
		this.telefone = telefone;
		this.rg = rg;
		this.orgaoEmissor = orgaoEmissor;
		this.idade = idade;
		this.endereco = endereco;
		this.bairro = bairro;
		this.cidade = cidade;
		this.pais = pais;
		this.estado = estado;
		this.cargo = cargo;
		this.dataContratacao = dataContratacao;
		this.estadoCivil = estadoCivil;
		this.salario = salario;
		this.qtdeFilhos = qtdeFilhos;
		this.carteiraTrabalho = carteiraTrabalho;
		this.horasdetrabalho = horadetrabalho;
	}

	public long getCpf() {
		return cpf;
	}

	public void setCpf(long cpf) {
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public Date getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public int getDdd() {
		return ddd;
	}

	public void setDdd(int ddd) {
		this.ddd = ddd;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}

	public long getRg() {
		return rg;
	}

	public void setRg(long rg) {
		this.rg = rg;
	}

	public String getOrgaoEmissor() {
		return orgaoEmissor;
	}

	public void setOrgaoEmissor(String orgaoEmissor) {
		this.orgaoEmissor = orgaoEmissor;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public Date getDataContratacao() {
		return dataContratacao;
	}

	public void setDataContratacao(Date dataContratacao) {
		this.dataContratacao = dataContratacao;
	}

	public String getEstadoCivil() {
		return estadoCivil;
	}

	public void setEstadoCivil(String estadoCivil) {
		this.estadoCivil = estadoCivil;
	}

	public String getSalario() {
		return salario;
	}

	public void setSalario(String salario) {
		this.salario = salario;
	}

	public int getQtdeFilhos() {
		return qtdeFilhos;
	}

	public void setQtdeFilhos(int qtdeFilhos) {
		this.qtdeFilhos = qtdeFilhos;
	}

	public long getCarteiraTrabalho() {
		return carteiraTrabalho;
	}

	public void setCarteiraTrabalho(long carteiraTrabalho) {
		this.carteiraTrabalho = carteiraTrabalho;
	}



	public String getHorasdetrabalho() {
		return horasdetrabalho;
	}



	public void setHorasdetrabalho(String horasdetrabalho) {
		this.horasdetrabalho = horasdetrabalho;
	}

}
