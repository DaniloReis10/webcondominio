package condominio.persistence;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import condominio.beans.*;

@WebServlet("/Listar")
public class Listar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Listar() {
        super();
   
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		List<Funcionario> funcionarios = (List<Funcionario>) new Listar().ListarFuncionario();
		out.print("<html><body>");
		out.println("<div align=\"center\">");
		out.println("<h1> Listagem de Funcionarios </h1>");
		
		out.println("<div id=conteudo_mostrar>"); //COME�O DA DIV
		out.println("<table border='1'>");
		out.println("<tr style='background-color: gray;'>");
		out.println("<td WIDTH=\"150\" align=\"center\">Cpf</td>");
		out.println("<td WIDTH=\"200\" align=\"center\">Nome</td>");
		out.println("<td WIDTH=\"200\" align=\"center\">Email</td>");
		out.println("<td WIDTH=\"120\" align=\"center\">Cargo</td>");
		out.println("<td WIDTH=\"100\" align=\"center\">Editar</td>");
		out.println("<td WIDTH=\"100\" align=\"center\">Excluir</td>");
		out.println("</tr>");
		out.println("</table>");

		for (Funcionario f : funcionarios) {
			out.println("<table border='1'>");
			out.println("<tr>");
			out.println("<td WIDTH=\"150\" align=\"center\">" + f.getCpf() + "</td>");
			out.println("<td WIDTH=\"200\" align=\"center\">" + f.getNome() + "</td>");
			out.println("<td WIDTH=\"200\" align=\"center\">" + f.getEmail() + "</td>");
			out.println("<td WIDTH=\"120\" align=\"center\">" + f.getCargo() + "</td>");
			out.println("<td WIDTH=\"100\" align=\"center\">" + "<a href='Editar.html? id="+ f.getCpf()
			+ "' action= \"Email.html\" method=\"get\">Editar</a> </td>");
			out.println("<td WIDTH=\"100\" align=\"center\">" + "<a href='Excluir?id=" + f.getCpf()
					+ "'action= \"Excluir\" method=\"get\">Excluir</a> </td>");
		}
			
			out.println("</table>");
			out.println("</td>");
			out.println("</tr>");
			out.println("</div>"); // FINAL DA DIV
		
		out.print("</form>");
		out.println("<br>");
		out.println("<form action= \"Menu.html\" method=\"get\">");
		out.println("<input type=\"submit\" value=\"Voltar\">");
		out.print("</form>");
		out.print("</div>");
		out.print("</body></html>");
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	public void listas(){
		
	}
	
	public ArrayList<Funcionario> ListarFuncionario() {
		Connection con = null;
		PreparedStatement stmt = null;
		ArrayList<Funcionario> exb = new ArrayList<>();
		try {
			con = Conexao.getConnection();
			stmt = con.prepareStatement("select * from condominio.funcinario ");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				long cpf = rs.getLong(1);
				String nome = rs.getString(2);
				String email = rs.getString(3);
				String cargo = rs.getString(16);
				Funcionario f = new Funcionario(cpf, nome, email, cargo); 
				exb.add(f);
			}

		} catch (SQLException ex) {
			System.out.println("Erro ao acessar o BD.");
			ex.printStackTrace();
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (Exception e1) {
				System.out.println("Erro ao tentar fechar a conex�o.");
			}
		}
		return exb;
	}

}
