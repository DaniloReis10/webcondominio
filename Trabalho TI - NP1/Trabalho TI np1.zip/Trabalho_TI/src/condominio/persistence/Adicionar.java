package condominio.persistence;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import condominio.beans.Funcionario;


@WebServlet("/Adicionar")
public class Adicionar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Adicionar() {
        super();
    
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			String cpf = request.getParameter("cpf");
			String nome = request.getParameter("nome");
			String email = request.getParameter("email");
			String sexo = request.getParameter("sexo");
			String dataNascimento = request.getParameter("datanascimento");
			String ddd = request.getParameter("ddd");
			String telefone = request.getParameter("telefone");
			String rg = request.getParameter("rg");
			String orgaoEmissor = request.getParameter("orgaoemissor");
			String idade = request.getParameter("idade");
			String endereco = request.getParameter("endereco");
			String bairro = request.getParameter("bairro");
			String cidade = request.getParameter("cidade");
			String pais = request.getParameter("pais");
			String estado = request.getParameter("estado");
			String cargo = request.getParameter("cargo");
			String dataContratacao = request.getParameter("datacontratacao");
			String estadoCivil = request.getParameter("estadocivil");
			String salario = request.getParameter("salario");
			String qtdeFilhos = request.getParameter("qtdFilhos");
			String cateiraTrabalho = request.getParameter("carteiratrabalho");
			String horasdetrabalho = request.getParameter("cargahoraria");
			Funcionario f = new Funcionario(Long.parseLong(cpf), nome, email, sexo, sdf.parse(dataNascimento), Integer.parseInt(ddd),
					Integer.parseInt(telefone), Long.parseLong(rg), orgaoEmissor, Integer.parseInt(idade), endereco, bairro, cidade, 
					pais, estado, cargo, sdf.parse(dataContratacao), estadoCivil, salario, Integer.parseInt(qtdeFilhos), Long.parseLong(cateiraTrabalho), horasdetrabalho);
				inserir(f);
				RequestDispatcher r = request.getRequestDispatcher("Menu.html");
				r.forward(request, response);
			
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}

	public void inserir(Funcionario f) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = Conexao.getConnection();
			stmt = con.prepareStatement("insert into condominio.funcinario values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			stmt.setLong(1, f.getCpf());
			stmt.setString(2, f.getNome());
			stmt.setString(3, f.getEmail());
			stmt.setString(4, f.getSexo());
			stmt.setTimestamp(5,new java.sql.Timestamp(f.getDataNascimento().getTime()));
			stmt.setInt(6, f.getDdd());
			stmt.setInt(7, f.getTelefone());
			stmt.setLong(8, f.getRg());
			stmt.setString(9, f.getOrgaoEmissor());
			stmt.setInt(10, f.getIdade());
			stmt.setString(11, f.getEndereco());
			stmt.setString(12, f.getBairro());
			stmt.setString(13, f.getCidade());
			stmt.setString(14, f.getPais());
			stmt.setString(15, f.getEstado());
			stmt.setString(16, f.getCargo());
			stmt.setTimestamp(17,new java.sql.Timestamp(f.getDataContratacao().getTime()));
			stmt.setString(18, f.getEstadoCivil());
			stmt.setString(19, f.getSalario());
			stmt.setInt(20, f.getQtdeFilhos());
			stmt.setLong(21, f.getCarteiraTrabalho());
			stmt.setString(22, f.getHorasdetrabalho());
			stmt.executeUpdate();

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (Exception e1) {
				System.out.println("Erro ao tentar fechar a conexão.");
			}
		}
	}
}
