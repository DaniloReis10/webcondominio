package condominio.persistence;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Excluir")
public class Excluir extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public Excluir() {
        super();
     
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idSet = request.getParameter("id");
		deletar(Long.parseLong(idSet));
		RequestDispatcher r = request.getRequestDispatcher("Listar");
		r.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	public void deletar(long numeroCodigo) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = Conexao.getConnection();
			stmt = con.prepareStatement("delete from condominio.funcinario where cpf = ?");

			stmt.setLong(1, numeroCodigo);

			stmt.executeUpdate();
		} catch (SQLException ex) {
			System.out.println("Erro ao acessar o BD.");
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (Exception e1) {
				System.out.println("Erro ao tentar fechar a conex�o.");
			}
		}

	}

}
